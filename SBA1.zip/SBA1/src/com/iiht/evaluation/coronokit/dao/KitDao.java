package com.iiht.evaluation.coronokit.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.iiht.evaluation.coronokit.model.CoronaKit;
import com.iiht.evaluation.coronokit.model.KitDetail;
import com.iiht.evaluation.coronokit.model.ProductMaster;

public class KitDao {

	private String jdbcURL = "jdbc:mysql://localhost:3306/coronakit";
	private String jdbcUsername;
	private String jdbcPassword;
	private Connection jdbcConnection;

	public KitDao(String jdbcURL, String jdbcUsername, String jdbcPassword) {
		this.jdbcURL = jdbcURL;
		this.jdbcUsername = jdbcUsername;
		this.jdbcPassword = jdbcPassword;
	}

	protected void connect() throws SQLException {
		if (jdbcConnection == null || jdbcConnection.isClosed()) {
			try {
				Class.forName("com.mysql.jdbc.Driver"); // Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				throw new SQLException(e);
			}
			jdbcConnection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		}
	}

	protected void disconnect() throws SQLException {
		if (jdbcConnection != null && !jdbcConnection.isClosed()) {
			jdbcConnection.close();
		}
	}

	/*
	 * public List<users> getuserList() throws ClassNotFoundException, SQLException
	 * { String sql="select * from users "; this.connect(); Statement
	 * stmt=this.jdbcConnection.createStatement(); ResultSet
	 * rs=stmt.executeQuery(sql); List<users> usr=new ArrayList<users>();
	 * while(rs.next()) { users u=new users(rs.getString("fname"),
	 * rs.getString("email"),rs.getString("age")); usr
	 * 
	 * }
	 * 
	 * rs.close(); stmt.close(); this.disconnect(); return products; }
	 */

	
	public void addProduct(String id) throws SQLException {
		String sql="select * From kit where productid=?";
		this.connect();
		PreparedStatement pstmt=this.jdbcConnection.prepareStatement(sql);
		pstmt.setString(1, id);
		ResultSet rs=pstmt.executeQuery();
		KitDetail record=null;
		while(rs.next())
		{
			record=new KitDetail(rs.getInt(id),
					rs.getInt("ck_id"), rs.getInt("productid"),
					rs.getInt("quantity"), rs.getInt("amount")
					);
			pstmt.close();
			
		String sql2="select * From productmaster where id=?";
		this.connect();
		this.jdbcConnection.prepareStatement(sql2);
		pstmt.setString(1, id);
		ResultSet rs2=pstmt.executeQuery();
		ProductMaster product=null;
				while(rs2.next()) {
					product =new ProductMaster(
							rs2.getInt(id),
							rs2.getString("productname"),
							rs2.getString("cost"),
							rs2.getString("productdescription"));
				}
			if(record==null) {
				String sql1="insert into kit(productid,quantity,amount) values(?,?,?)";
				PreparedStatement pstmt1=this.jdbcConnection.prepareStatement(sql1);
				pstmt1.setString(1, id);
				pstmt1.setInt(2, 1);
				pstmt1.setString(3, product.getCost());
				pstmt1.execute();
				pstmt1.close();
			}else {
				String sql3="update kit set id=?, quantity=?, amount=? where id=?";
				PreparedStatement pstmt3=this.jdbcConnection.prepareStatement(sql3);
				int a=record.getQuantity()+1;
				pstmt3.setInt(1, a);
				String b=record.getAmount()+product.getCost();
				pstmt3.setString(1, b);
				pstmt3.setInt(3,record.getId());
				pstmt3.executeUpdate();
				pstmt3.close();
			}
			this.disconnect();
					
		}
	}
		
		public CoronaKit getLastOrderSummary() throws SQLException {
			String sql="select * From kit where id =(select max(id) from kit)";
			this.connect();
			PreparedStatement pstmt=this.jdbcConnection.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery();
			
				CoronaKit ck=new CoronaKit(
						rs.getInt(1),
						rs.getString("name"),
						rs.getString("email"),
						rs.getString("contact"),
						rs.getInt("amount"),
						rs.getString("address"),
						rs.getString("orderdate"),
						true
						);
			
		
		
			pstmt.close();
			this.disconnect();
			
			return ck;
		}
}
