package com.iiht.evaluation.coronokit.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iiht.evaluation.coronokit.dao.ProductMasterDao;
import com.iiht.evaluation.coronokit.model.ProductMaster; 

@WebServlet("/admin")	
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ProductMasterDao productMasterDao;
	
	public AdminController() {
		super();
	}
	
		
	public void setProductMasterDao(ProductMasterDao productMasterDao) {
		this.productMasterDao = productMasterDao;
	}

	public void init(ServletConfig config) {
		String jdbcURL = config.getServletContext().getInitParameter("jdbcURL");//getServletContext().getInitParameter("jdbcURL");
		String jdbcUsername = config.getServletContext().getInitParameter("jdbcUsername");
		String jdbcPassword = config.getServletContext().getInitParameter("jdbcPassword");

		this.productMasterDao = new ProductMasterDao(jdbcURL, jdbcUsername, jdbcPassword);

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action =  request.getParameter("action");
		String viewName = "";
		try {
			switch (action) {
			case "login" : 
				viewName = adminLogin(request, response);
				break;
			case "newproduct":
				viewName = showNewProductForm(request, response);
				break;
			case "insertproduct":
				viewName = insertProduct(request, response);
				break;
			
			case "deleteproduct":
				viewName = deleteProduct(request, response);
				break;
			case "editproduct":
				viewName = showEditProductForm(request, response);
				break;
			case "updateproduct":
				viewName = updateProduct(request, response);
				break;
			case "list":
				viewName = listAllProducts(request, response);
				break;	
			case "logout":
				viewName = adminLogout(request, response);
				break;	
			default : viewName = "notfound.jsp"; break;		
			}
		} catch (Exception ex) {
			throw new ServletException(ex.getMessage());
		}
		RequestDispatcher dispatch = 
					request.getRequestDispatcher(viewName);
		dispatch.forward(request, response);
		
		
	}

	
	
	private String deleteProduct(HttpServletRequest request, HttpServletResponse response) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		//String id=request.getParameter("id");
		String id=request.getParameter("id");
		this.productMasterDao.deleteProduct(id);
		
		
		
		return "admin?action=list";
	}



	private String adminLogout(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		return "";
	}

	
	private String adminLogin(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String loginid=request.getParameter("loginid");
		String password=request.getParameter("password");
		System.out.println(loginid);
		System.out.println(password);
		if(loginid.equals("Admin") && password.equals("12345")) 
			response.sendRedirect("listproduct.jsp");
		//request.getRequestDispatcher("listproduct.jsp").forward(request, response);
			
		else 
		
			response.sendRedirect("index.jsp");
			//request.getRequestDispatcher("error.jsp").forward(request, response);
		
		
		return null; 
		
			}
	
	
	private String listAllProducts(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException  {
		// TODO Auto-generated method stub
		List<ProductMaster> products=this.productMasterDao.getProductList();
		request.setAttribute("products", products);
		return "listproducts.jsp";
	}

	private String updateProduct(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		String id=request.getParameter("id");
		String prodname=request.getParameter("productname");
		String cost=request.getParameter("cost");
		String proddesc=request.getParameter("productdescription");
		this.productMasterDao.editProd(id, prodname, cost, proddesc);
		return "admin?action=list";
		
	}

	private String showEditProductForm(HttpServletRequest request, HttpServletResponse response) {
	
		return "editproduct.jsp";
	}

	
	private String insertProduct(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		String id=request.getParameter("id");
		String prodname=request.getParameter("productname");
		String cost=request.getParameter("cost");
		String proddesc=request.getParameter("productdescription");
		this.productMasterDao.addNewProd(id, prodname, cost, proddesc);
		return "admin?action=list";
	}

	private String showNewProductForm(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		return "newproduct.jsp";
	}

	
	/*public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}*/
	
	}
	
